package com.agrinova.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val green = Color.rgb(23, 107, 67)
    private val deep = Color.rgb(16, 71, 47)
    private val cream = Color.rgb(245, 247, 239)
    private val ink = Color.rgb(23, 38, 30)
    private val muted = Color.rgb(105, 120, 110)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = deep
        window.navigationBarColor = deep
        showHome()
    }

    private fun background(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 4, 0, 4)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; setTextColor(deep); setBackgroundColor(Color.rgb(223,243,165))
            isAllCaps = false; textSize = 14f; setOnClickListener { action() }
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(18, 17, 18, 17)
        background = background(Color.WHITE)
        elevation = 3f
        val params = LinearLayout.LayoutParams(-1, -2); params.setMargins(0, 0, 0, 14)
        layoutParams = params
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(cream)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 16, 20, 16); setBackgroundColor(deep)
        }
        header.addView(text("🌿", 27f, Color.WHITE, true))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0) }
        brand.addView(text("AgriNova AI", 20f, Color.WHITE, true))
        brand.addView(text("SMART FARMING, BETTER HARVESTS", 9f, Color.rgb(223,243,165), true))
        header.addView(brand)
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,18,16,20) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)

        val hero = card().apply { setBackgroundColor(deep) }
        hero.addView(text("YOUR DIGITAL AGRONOMIST", 10f, Color.rgb(223,243,165), true))
        hero.addView(text("Grow smarter.\nHarvest better.", 31f, Color.WHITE, true))
        hero.addView(text("Weather insights, crop guides and plant-health support in one place.", 14f, Color.rgb(225,238,228)))
        hero.addView(button("Check plant health  ↗") { showHealth() })
        content.addView(hero)

        val weather = card()
        weather.addView(text("🌦️  WEATHER OUTLOOK", 11f, green, true))
        weather.addView(text("Live forecast not connected yet", 20f, ink, true))
        weather.addView(text("Connect a weather provider to show local temperature, rain probability, humidity and wind. Never use demo values for farm decisions.", 13f, muted))
        weather.addView(button("Weather setup details") { info("Weather integration", "The APK starter needs a weather API connection and location permission to provide a live local forecast.") })
        content.addView(weather)

        val crops = card()
        crops.addView(text("🌾  CROP GUIDES", 11f, green, true))
        crops.addView(text("Guidance for everyday farming", 20f, ink, true))
        crops.addView(text("Rice • Wheat • Maize • Tomato • Potato • Chilli • Guava • Mango • Banana", 14f, muted))
        crops.addView(button("Explore crop guidance") { showCrops() })
        content.addView(crops)

        val health = card()
        health.addView(text("📷  PLANT HEALTH", 11f, green, true))
        health.addView(text("Describe a plant problem", 20f, ink, true))
        health.addView(text("Upload a photo and enter symptoms. AI diagnosis must be connected and validated before commercial use.", 13f, muted))
        health.addView(button("Open plant health assistant") { showHealth() })
        content.addView(health)

        content.addView(text("Prototype v0.1 • Not a substitute for local agronomic advice", 11f, muted))
    }

    private fun showCrops() {
        content.removeAllViews()
        content.addView(text("Crop guidance", 27f, ink, true))
        content.addView(text("Starter summaries only. Full guides should be localized by crop variety, climate, soil and growth stage.", 13f, muted))
        val list = listOf(
            "🌾 Rice" to "Use healthy seed, plan nursery and transplanting, manage water carefully, scout regularly for pests and disease.",
            "🌽 Maize" to "Follow locally suitable spacing, manage nutrients by soil test, monitor fall armyworm and protect pollination.",
            "🍅 Tomato" to "Avoid waterlogging, keep watering consistent, support plants and inspect leaves and fruits frequently.",
            "🥔 Potato" to "Use healthy seed tubers, earth up plants, ensure drainage and watch for late blight after humid weather.",
            "🌶️ Chilli" to "Use a healthy nursery, maintain drainage, scout for thrips and mites, and avoid unverified spray mixtures.",
            "🍐 Guava" to "Prune appropriately for the region, avoid waterlogging, monitor fruit fly and base fertilizer on tree age and soil.",
            "🥭 Mango" to "Manage canopy and nutrition by growth stage, monitor fruit fly and use region-specific flowering advice.",
            "🍌 Banana" to "Keep drainage clear, select healthy suckers, support heavy bunches and manage potassium based on local guidance."
        )
        list.forEach { (name, guide) ->
            val c = card(); c.addView(text(name,18f,green,true)); c.addView(text(guide,14f,muted)); content.addView(c)
        }
        content.addView(button("← Back to dashboard") { showHome() })
    }

    private fun showHealth() {
        content.removeAllViews()
        content.addView(text("Plant health assistant", 26f, ink, true))
        content.addView(text("This starter does not diagnose disease from a photo yet. Share details to prepare a useful field report.", 13f, muted))
        val crop = Spinner(this)
        crop.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Rice","Tomato","Potato","Chilli","Wheat","Guava","Mango","Other / unknown"))
        content.addView(text("Crop",14f,ink,true)); content.addView(crop)
        val part = Spinner(this)
        part.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Leaf","Fruit","Stem","Root","Whole plant"))
        content.addView(text("Affected part",14f,ink,true)); content.addView(part)
        val symptoms = EditText(this).apply {
            hint = "Describe symptoms: spots, yellowing, curling, wilting..."
            minLines = 4; gravity = Gravity.TOP; textSize = 14f
            setPadding(12,12,12,12); background = background(Color.WHITE,14f)
        }
        content.addView(text("Symptoms",14f,ink,true))
        content.addView(symptoms, LinearLayout.LayoutParams(-1,150))
        content.addView(button("Prepare field checklist") {
            val report = "Crop: ${crop.selectedItem}\nAffected part: ${part.selectedItem}\nSymptoms: ${symptoms.text}\n\nNext steps:\n• Photograph the whole plant and a close-up in good light.\n• Check several affected and healthy plants.\n• Review recent irrigation, rain and fertilizer use.\n• Confirm the cause with a qualified local agronomist before treatment.\n\nThis is not an AI diagnosis. Do not select or apply pesticide from this checklist."
            info("Field checklist", report)
        })
        content.addView(text("Safety: pesticide registrations and labels differ by country. A future release must check crop, location, product registration, label dose, protective equipment and pre-harvest interval.", 12f, muted))
        content.addView(button("← Back to dashboard") { showHome() })
    }

    private fun info(title: String, message: String) {
        android.app.AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }
}
