# AgriNova AI — Android APK starter

This is a native Android Studio starter project in Kotlin. It creates a basic Android app shell for AgriNova AI. It is not yet the full production app and does not include live weather, cloud AI diagnosis, user accounts, or a verified pesticide database.

## Build an APK
1. Install Android Studio on a computer.
2. Create/open a project using the `app` folder in this starter (or create an Empty Views Activity and replace the files).
3. Use Android Gradle Plugin 8.5.2, Gradle 8.7, and JDK 17.
4. Sync Gradle, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For Play Store release, create a signed Android App Bundle (AAB), test on devices, and complete Play Console requirements.

## Safety and production notes
- Weather screen is explicitly marked as not connected until a weather provider is configured.
- The plant-health screen is a symptom intake and photo picker; it does not claim to diagnose from an image.
- Never recommend a pesticide until crop/country registration, label instructions, dose, pre-harvest interval and protective equipment are validated against current local sources.
- For a commercial release, add backend authentication, privacy controls, monitoring, tests, localization, and expert-reviewed agronomic content.

## Project contents
- `settings.gradle.kts`, root `build.gradle.kts`, `gradle.properties`
- `app/build.gradle.kts`, manifest and Kotlin activity
- Simple native Material-style UI built with standard Android Views to keep the starter easy to adapt.
